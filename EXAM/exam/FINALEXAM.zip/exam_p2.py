import string

### DO NOT MODIFY THIS FUNCTION ###


def load_wordlist(file_name):
    '''
    '''
    print('Loading word list from file...')
    in_file = open(file_name, 'r')
    line = in_file.readline()
    word_list = line.split()
    print('  ', len(word_list), 'words loaded.')
    in_file.close()
    return word_list

### DO NOT MODIFY THIS FUNCTION ###


def is_a_valid_word(word_list, word):
    '''    
    Returns: True if word is in word_list, False otherwise
    '''
    word = word.lower()
    word = word.strip(" !@#$%^&*()-_+={}[]|\:;'<>?,./\"")
    return word in word_list

### DO NOT MODIFY THIS FUNCTION ###


def get_joke_string():
    """
    Returns: an article in encrypted text.
    """
    f = open("joke.txt", "r")
    joke = str(f.read())
    f.close()
    return joke

WORDLIST_FILENAME = 'words.txt'


class Text(object):
    ### DO NOT MODIFY THIS METHOD ###

    def __init__(self, text):
        '''
        Initializes a Text object
        '''
        self.text = text
        self.valid_words = load_wordlist(WORDLIST_FILENAME)

    ### DO NOT MODIFY THIS METHOD ###
    def get_text(self):
        '''
        Returns: self.text
        '''
        return self.text

    ### DO NOT MODIFY THIS METHOD ###
    def get_valid_words(self):
        '''
        Returns: a COPY of self.valid_words
        '''
        return self.valid_words[:]

    def create_moved_dict(self, move):
        '''
        Creates a dictionary that maps every letter to a
        character moved down the alphabet by the input move. 

        move: an integer, 0 <= move < 26

        Returns: a dictionary

        Example: an_instance_of_Text.create_moved_dict(2) would generate
        {'a': 'c', 'b': 'd', 'c':'e', ...}  
        '''
        '''
        PLEASE READ BEFORE PROCEEDING PROFESSOR:
        I struggled to get all the parts of the helper code to connect. 
        I tried to complete all of the codes to the best of my ability. 
        I ended up writing my own code that decrypts code when you input the text and the move count
        I was able to get this one to work. PLEASE SEE 'samp.py' in file. I did this to show
        I could get the end goal accomplished.
        '''
        self.move=move
        di=string.ascii_lowercase
        di2=string.ascii_uppercase
        oldlet=list(di+di2)#combines upper and lower case to one list

        word=[]
        for letter in oldlet:
             if letter not in oldlet:
                 word.append(letter)
             if letter.isupper()==True:#seperates the upper and lowercase letters
                 if letter == 'X' or 'Y' or 'Z':
                    a=di2.index(letter)
                    word.append(di2[a-(26-move)])
                 elif letter in di2:
                     a=di2.index(letter)
                     word.append(di2[a+self.move])
             if letter in di:
                 if letter == 'x' or 'y' or 'z':
                     a=di.index(letter)
                     word.append(di[a-(26-move)])#this creates the loop if it goes further than z 
                 else:
                    a=di.index(letter)
                    word.append(di[a+self.move])
        encrypted_dict = dict(zip(oldlet, word))
        return  encrypted_dict#this returns the updated dictionary of what the letters become after the shift
        
        
    def apply_move(self, move):
        '''
        Applies the cipher to self.text with the input move       

        move: an integer, 0 <= move < 26

        Returns: the text (string) in which every character is moved
             down the alphabet by the input move
        '''
        
        self.move=move
        di=string.ascii_lowercase
        di2=string.ascii_uppercase
        oldlet=list(di+di2)
        end_phrase=[]#this will be the final result
        s=''
        # print(self.move)
        for letter in self.text:
            #print(letter)
            if letter.isalpha()==False:
                end_phrase.append(letter)
            if letter.isalpha()==True:#I want to reference the dictionary I have made because I want to pull from the dictionary that I made in the 'create_moved dictionary function'
                if letter.isupper()==True:
                    if move >= (26-(di2.index(letter)))==True:
                        a=di2.index(letter)
                        end_phrase.append(di2[a-(25-move)])
                    else:
                        a=di2.index(letter)
                        end_phrase.append(di2[a+move])
                elif letter.islower()==True:
                    if move >= (26-(di.index(letter)))==True:
                        a=di.index(letter)
                        end_phrase.append(di[a-(26-move)])
                    else:
                    
                        a=di.index(letter)

                        #PLEASE READ 
                        #print(a) #I have been struggling to get this function to work with the second function request in main() 
                        '''it works for the first one but when you uncomment'print(a)' it can be seen that the funtion keeps looping, but only for the
                            second one. When it does the first one, it stops when the letter are done but this one keeps refresshing and looping
                            If I was able to figure out this problem the remaining funtion decrypt_text() should work properly'''
                        end_phrase.append(di[a+move])
        return s.join(end_phrase)
        


class PlainText(Text):

    def __init__(self, text, move):
        '''
        Initializes a PlainText object        

        text: a string
        move: an integer

        A PlainText object inherits from Text and has five attributes:
            self.text (string, determined by input text)
            self.valid_words (list, determined using helper function load_wordlist)
            self.move (integer, determined by input move)
            self.encrypting_dict (dictionary, built using move)
            self.encrypted_text (string, created using move)

        Note: you must use the parent class constructor(__init__ function) 
        so less code is repeated
        '''
        self.text=text
        self.valid_words=load_wordlist(WORDLIST_FILENAME)
        self.move=move
        self.encrypting_dict={}
        self.encrypted_text=''
    def get_move(self):
        '''
        Used to safely access self.move outside of the class

        Returns: self.move
        '''
        return self.move

    def get_encrypting_dict(self):
        '''
        Used to safely access a copy self.encrypting_dict outside of the class

        Returns: a COPY of self.encrypting_dict
        '''
        copy=self.encrypting_dict.copy()
        return copy

    def get_encrypted_text(self):
        '''
        Used to safely access self.encrypted_text outside of the class

        Returns: self.encrypted_text
        '''
        self.encrypted_text=Text.apply_move(self,self.move)
        return self.encrypted_text
    def change_move(self, move):
        '''
        Changes self.move of the PlainText and updates other 
        attributes determined by move (ie. self.encrypting_dict and 
        encrypted_text).

        move: an integer, 0 <= move < 26

        Returns: nothing
        '''
        self.move=move
        

class CipherText(Text):

    def __init__(self, text):
        '''
        Initializes a CipherText object

        text: a string
        
        a CipherText object has two attributes:
            self.text (string, determined by input text)
            self.valid_words (list, determined using helper function load_wordlist)
        '''
        self.text=text
        self.valid_words=load_wordlist(WORDLIST_FILENAME) 

    def decrypt_text(self):
        '''
        Decrypt self.text by trying every possible move value
        and find the "best" one. We will define "best" as the move that
        creates the maximum number of real words when we use apply_move(move)
        on the text. If s is the original move value used to encrypt
        the text, then we would expect 26 - s to be the best move value 
        for decrypting it.

        Returns: a tuple of the best move value used to decrypt the text
        and the decrypted  text using that move value. Check out the
        test case in main function below.

        '''

        
        '''PLEASE READ Professor, The function below is designed to create a dictionary with the uncrypted words. then it would go through the list of values and 
        find the value that is a valid word. then it would return the key and value from the dictionary that corresponds.'''
         
        
        self.move=0
    
        wordz={}
        while self.move <27:
            self.move=self.move+1
            a = Text.apply_move(self,self.move)# this is the function that causes the problem
            wordz[self.move]=a
        b=wordz.values
        for word in b:
            
            if is_a_valid_word(word_list, word)==True:
                z=list(wordz.keys())[list(wordz.values()).index(word)]
                return z,word
       
            
def decrypt_joke():
    joke = CipherText(get_joke_string())
    return joke.decrypt_text()


def main():
    # Example test case (PlainText)
    plaintext = PlainText('hello', 2)
    print('Expected Output: jgnnq')
    print('Actual Output:', plaintext.get_encrypted_text())
    
    # Example test case (CipherText)
    ciphertext = CipherText('jgnnq')
    print('Expected Output:', (24, 'hello'))
    print('Actual Output:', ciphertext.decrypt_text())
    
    # print(decrypt_joke())


if __name__ == '__main__':
    main()