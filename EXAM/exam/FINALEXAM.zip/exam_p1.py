
def speak_Chinese(number):
    '''
    number: a integer, 0<=number<99

    Returns: a string that is the number in Chinese
    '''
    trans={'0':'ling', '1':'yi','2':'er','3':'san','4':'si','5':'wu','6':'liu','7':'qi','8':'ba','9':'jiu','10':'shi','100':'bai'}
    if int(number) <= 10:
        return trans[number]
    if int(number) >=11 and int(number) <= 19:
       num=str(number)
       s=' '
       s2=trans['10'],trans[num[1]]
       return s.join(s2) 
    if int(number) >=20 and int(number) <= 99:
      num=str(number)
      s=' '
      s2=trans[num[0]],trans['10']
      s3=trans[num[0]],trans['10'],trans[num[1]]
      if num[1]=='0':
        return s.join(s2)
      else:
        return s.join(s3)
    if int(number) >=100 and int(number) <= 999:
      num=str(number)
      s=' '
      s2=trans[num[0]],trans['100'] #below are the different formats based on the restraints of the number
      s3=trans[num[0]],trans['100'],trans[num[1]],trans['10']
      s4=trans[num[0]],trans['100'],trans['0'],trans[num[2]]
      s5=trans[num[0]],trans['100'],trans[num[1]],trans['10'],trans[num[2]]
      
      if num[1]=='0'and num[2]=='0':
        return s.join(s2)
      if num[2]=='0':
        return s.join(s3)
      if num[1]=='0':
        return s.join(s4)
      else:
        return s.join(s5)
           
# For testing
def main():
    print(speak_Chinese('36'))
    print('In Chinese: 36 = san shi liu')
    print(speak_Chinese('20'))
    print('In Chinese: 20 = er shi')
    print(speak_Chinese('16'))
    print('In Chinese: 16 = shi liu')
    print(speak_Chinese('109'))
    print('In Chinese: 109 = yi bai ling jiu')
    print(speak_Chinese('999'))
    print('In Chinese: 999 = jiu bai jiu shi jiu')
    print(speak_Chinese('200'))
    print('200')
    print(speak_Chinese('9'))
    print('9')

if __name__ == '__main__':
    main()
