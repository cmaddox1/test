import string

#this function decrypts txt when you put in self and mov
def create_moved_dict(self, move):
    '''
    Creates a dictionary that maps every letter to a
    character moved down the alphabet by the input move. 

    move: an integer, 0 <= move < 26

    Returns: a dictionary

    Example: an_instance_of_Text.create_moved_dict(2) would generate
    {'a': 'c', 'b': 'd', 'c':'e', ...}  
    '''
    di=string.ascii_lowercase
    di2=string.ascii_uppercase
    word=[]
    s=''
    for letter in self:
        if letter not in di and letter not in di2:
            word.append(letter)
        if letter.isupper()==True:
            if letter == 'X' or 'Y' or 'Z':
                a=di2.index(letter)
                word.append(di2[a-(26-move)])
            elif letter in di:
                a=di2.index(letter)
                word.append(di2[a+move])
        if letter in di:
            if letter == 'x' or 'y' or 'z':
                a=di.index(letter)
                word.append(di[a-(26-move)])
            elif letter in di:
                a=di.index(letter)
                word.append(di[a+move])
    print(s.join(word))


create_moved_dict('Hello, World!', 3)